import pygame
import random
from os import path

img_dir = path.join(path.dirname(__file__), 'img')

WIDTH = 480
HEIGHT = 600
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

pygame.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Голодный зайчик.")
clock = pygame.time.Clock()

font_name = pygame.font.match_font('Cambria')


def draw_text(surf, text, size, x, y):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text, True, BLACK)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)


def menu():
    intro = True
    smallfont = pygame.font.Font(None, 30)
    while intro == True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif event.type == pygame.KEYDOWN:
                intro = False

        pygame.display.set_caption('Голодный зайка')
        size = WIDTH, HEIGHT = 480, 600
        screen = pygame.display.set_mode(size)
        menu = pygame.image.load("img/place_4.png").convert()
        screen.blit(menu, (0, 0))
        text = smallfont.render("Для запуска игры", True, 'purple4')
        text_2 = smallfont.render("ГОЛОДНЫЙ ЗАЙКА", True, 'dark slate gray')
        text_3 = smallfont.render("Нажми на пробел.", True, 'purple4')
        screen.blit(text, [140, 240])
        screen.blit(text_3, [145, 260])
        screen.blit(text_2, [140, 100])
        pygame.display.update()


menu()



class Player(pygame.sprite.Sprite):

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(player_img, (50, 80))
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 10
        self.speedx = 0

    def update(self):
        self.speedx = 0
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_LEFT]:
            self.speedx = -10
        if keystate[pygame.K_RIGHT]:
            self.speedx = 8
        self.rect.x += self.speedx
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0



class Mob(pygame.sprite.Sprite):

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = burger_img
        self.image.set_colorkey((0, 0, 0))
        self.rect = self.image.get_rect()
        self.rect_1 = self.image.get_rect()
        self.rect.x = random.randrange(WIDTH - self.rect.width)
        self.rect.y = random.randrange(-100, -40)
        self.speedy = random.randrange(1, 8)
        self.speedx = random.randrange(-3, 3)

    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > HEIGHT + 10 or self.rect.left < -25 or self.rect.right > WIDTH + 20:
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1, 8)


background = pygame.image.load(path.join(img_dir, "place_1.png")).convert()

background_rect = background.get_rect()
player_img = pygame.image.load(path.join(img_dir, "playerShip1_orange-removebg-preview-removebg-preview.png")).convert()
burger_img = pygame.image.load(path.join(img_dir, "burger.png")).convert()

all_sprites = pygame.sprite.Group()

burger = pygame.sprite.Group()
player = Player()
all_sprites.add(player)

for i in range(10):
    m = Mob()
    all_sprites.add(m)
    burger.add(m)

calories = 0
running = True


while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    all_sprites.update()

    level_unit = 1

    hits = pygame.sprite.spritecollide(player, burger, False)

    if hits:
        calories += 25

    if calories < -1000 or calories > 7000:
        screen.blit(background, background_rect)
        draw_text(screen, "GAME OVER", 64, WIDTH / 2, HEIGHT / 4)
        kilogramms = calories // 1000
        if calories > 0:
            draw_text(screen, 'Вы набрали ' + str(kilogramms) + ' кг', 35, WIDTH / 2, 250)
        elif calories == 0:
            draw_text(screen, 'Зайчик побегал просто так', 35, WIDTH / 2, 250)
        else:
            draw_text(screen, 'Вы похудели на ' + str(abs(kilogramms)) + ' кг', 35, WIDTH / 2, 250)

        pygame.display.flip()

        waiting = True

        while waiting:
            clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.KEYUP:
                    waiting = False

        # print('Game Over')
        # running = False

    if 1500 < calories < 3000:
        background = pygame.image.load(path.join(img_dir, "place_3.png")).convert()
        level_unit = 2

    elif (3000 < calories < 5000):
        background = pygame.image.load(path.join(img_dir, "place_5.png")).convert()
        level_unit = 4

    elif (5000 < calories < 10000):
        background = pygame.image.load(path.join(img_dir, "place_2.png")).convert()
        level_unit = 6



    calories = calories - abs(player.speedx)
    calories -= level_unit
    # print(calories)
    screen.fill(BLACK)
    screen.blit(background, background_rect)
    draw_text(screen, str(calories), 20, WIDTH / 2, 10)
    draw_text(screen, 'Калории:', 20, WIDTH / 2.8, 10)

    all_sprites.draw(screen)

    pygame.display.flip()

pygame.quit()